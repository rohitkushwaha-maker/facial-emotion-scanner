import streamlit as st
import numpy as np
import cv2
from PIL import Image
from tensorflow.keras.models import load_model

st.set_page_config(page_title="Facial Emotion Scanner", page_icon="😊", layout="centered")

EMOTIONS = ("angry", "disgust", "fear", "happy", "sad", "surprise", "neutral")
MODEL_PATH = "best_model.h5"

@st.cache_resource
def get_model():
    return load_model(MODEL_PATH, compile=False)

@st.cache_resource
def get_face_detector():
    path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(path)
    if detector.empty():
        raise RuntimeError("Could not load the OpenCV face detector.")
    return detector

model = get_model()
face_detector = get_face_detector()

st.title("😊 Facial Emotion Scanner")
st.write("Upload a face image or take a photo. The model detects one of seven emotions.")

source = st.radio("Choose input", ["Upload image", "Use camera"], horizontal=True)

uploaded = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"]) if source == "Upload image" else st.camera_input("Take a photo")

if uploaded is not None:
    pil_image = Image.open(uploaded).convert("RGB")
    rgb = np.array(pil_image)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    faces = face_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))

    result = rgb.copy()

    if len(faces) == 0:
        st.warning("No face detected. Try a clear, front-facing photo with good lighting.")
    else:
        for (x, y, w, h) in faces:
            face = rgb[y:y+h, x:x+w]
            face = cv2.resize(face, (224, 224), interpolation=cv2.INTER_AREA)
            pixels = face.astype("float32") / 255.0
            pixels = np.expand_dims(pixels, axis=0)

            prediction = model.predict(pixels, verbose=0)[0]
            index = int(np.argmax(prediction))
            emotion = EMOTIONS[index]
            confidence = float(prediction[index]) * 100

            cv2.rectangle(result, (x, y), (x+w, y+h), (0, 255, 0), 3)
            label = f"{emotion} ({confidence:.1f}%)"
            cv2.putText(result, label, (x, max(30, y-10)), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)

        st.image(result, caption="Emotion detection result", use_container_width=True)
        st.success(f"Detected {len(faces)} face(s).")

        if len(faces) == 1:
            x, y, w, h = faces[0]
            face = rgb[y:y+h, x:x+w]
            face = cv2.resize(face, (224, 224), interpolation=cv2.INTER_AREA)
            prediction = model.predict(np.expand_dims(face.astype("float32") / 255.0, axis=0), verbose=0)[0]
            index = int(np.argmax(prediction))
            st.metric("Detected emotion", EMOTIONS[index].title(), f"{prediction[index]*100:.1f}% confidence")

st.divider()
st.caption("Educational/demo project. Emotion predictions are model estimates and should not be treated as definitive judgments about a person's mental state.")
