# Facial Emotion Scanner — Streamlit Deployment

This project deploys the trained `best_model.h5` facial-emotion classifier as a web application.

## Features
- Upload JPG/JPEG/PNG images
- Use the browser camera
- Detect multiple faces
- Predict 7 emotions: angry, disgust, fear, happy, sad, surprise, neutral
- Display face bounding boxes and confidence

## Deploy to Streamlit Community Cloud

1. Create a GitHub repository, for example `facial-emotion-scanner`.
2. Upload these files to the repository:
   - `app.py`
   - `best_model.h5`
   - `requirements.txt`
3. Open Streamlit Community Cloud and sign in with GitHub.
4. Create a new app and select your repository.
5. Set the main file to `app.py`.
6. Deploy.
7. Streamlit will give you a public HTTPS URL that you can share.

Example URL format:
`https://your-app-name.streamlit.app`

## Important
The 17 MB model file is small enough for a normal Git repository, but if GitHub rejects it because of repository/file limits, use Git LFS for `best_model.h5` or another model-storage method.
